
function mi_funcion1()
    {
        window.open("Front-end.html", "Diseño Web", "width=300, height=200")
    }

function mi_funcion2()
    {
        window.open("Wireframes.html", "Diseño Web", "width=300, height=200")
    }
function mi_funcion3()
    {
        window.open("Automation.html", "Diseño Web", "width=300, height=200")
    }
function mi_funcion4()
    {
        window.open("Back-end.html", "Diseño Web", "width=300, height=200") 
    }
function mi_funcion5()
    {
        window.open("Plataforms.html", "Diseño Web", "width=300, height=200")
    }
function mi_funcion6()
    {
        window.open("others.html", "Diseño Web", "width=300, height=200")
    }
function mi_funcion7()
    {
        window.open("Frameworks.html", "Diseño Web", "width=300, height=200")
    }
function mi_funcion8()
    {
        window.open("Vector.html", "Diseño Web", "width=300, height=200")
    }
